$(document).ready(function(){
  console.log(getCookie("veri"));

});
